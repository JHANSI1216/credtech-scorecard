print('Scoring engine placeholder')
